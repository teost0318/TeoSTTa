function Chatdc ()
    outputChatBox("#FFFFFFUnete a nuestra comunidad de Discord: #0033FFhttps://discord.gg/ASzyPPQu6Y.", 255,255,255,true)
end

addCommandHandler("discord",Chatdc)

function Chatweb ()
    outputChatBox("#00FF12Unete a nuestra comunidad Poniendo: #FF0000/youtube #001EFF/discord #8000FF/tiktok", 0,255,18,true)
end

addCommandHandler("web",Chatweb)

function Chatyt ()
    outputChatBox("#FFFFFFNuestro Youtube: #FF0000/youtube: https://www.youtube.com/channel/UCxXQt1OKpqsswg2ZYm0XuzQ", 255,255,255,true)
end

addCommandHandler("youtube",Chatyt)

function Chattiktok ()
    outputChatBox("#FFFFFFNuestro Tiktok: #8000FF/tiktok: https://www.tiktok.com/@proyectopaisitasrp", 255,255,255,true)
end

addCommandHandler("tiktok",Chattiktok)
